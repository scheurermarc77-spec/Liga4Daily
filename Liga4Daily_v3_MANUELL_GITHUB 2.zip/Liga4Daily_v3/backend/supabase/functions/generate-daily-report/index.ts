import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY") ?? "";
const OPENAI_MODEL = Deno.env.get("OPENAI_MODEL") ?? "gpt-5.5";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const CRON_SECRET = Deno.env.get("CRON_SECRET") ?? "";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-secret",
};

function zurichDateISO(): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Zurich",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

function generatedAtZurich(): string {
  const parts = new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Europe/Zurich",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).format(new Date()).replace(" ", "T");
  return `${parts}+02:00`;
}

function extractSources(response: any): Array<{ title: string; url: string }> {
  const map = new Map<string, string>();

  for (const item of response.output ?? []) {
    if (item?.type === "web_search_call") {
      for (const source of item?.action?.sources ?? []) {
        if (source?.url) map.set(source.url, source.title ?? "");
      }
    }

    if (item?.type === "message") {
      for (const content of item?.content ?? []) {
        for (const annotation of content?.annotations ?? []) {
          if (annotation?.type === "url_citation" && annotation?.url) {
            map.set(annotation.url, annotation.title ?? map.get(annotation.url) ?? "");
          }
        }
      }
    }
  }

  return Array.from(map.entries())
    .slice(0, 12)
    .map(([url, title]) => ({
      url,
      title: title || new URL(url).hostname,
    }));
}

const schema = {
  type: "object",
  additionalProperties: false,
  properties: {
    report_date: { type: "string" },
    generated_at: { type: "string" },
    title: { type: "string" },
    lead: { type: "string" },
    review: { type: "string" },
    current_situation: { type: "string" },
    outlook: { type: "string" },
    eschenbach: {
      type: "object",
      additionalProperties: false,
      properties: {
        rank: { type: "integer" },
        played: { type: "integer" },
        wins: { type: "integer" },
        draws: { type: "integer" },
        losses: { type: "integer" },
        goals_for: { type: "integer" },
        goals_against: { type: "integer" },
        goal_difference: { type: "integer" },
        points: { type: "integer" },
        form: { type: "string" },
      },
      required: ["rank", "played", "wins", "draws", "losses", "goals_for", "goals_against", "goal_difference", "points", "form"],
    },
    recent_results: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          date: { type: "string" },
          home: { type: "string" },
          away: { type: "string" },
          home_goals: { type: "integer" },
          away_goals: { type: "integer" },
          is_eschenbach: { type: "boolean" },
          note: { type: "string" },
        },
        required: ["date", "home", "away", "home_goals", "away_goals", "is_eschenbach", "note"],
      },
    },
    standings: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          rank: { type: "integer" },
          team: { type: "string" },
          played: { type: "integer" },
          wins: { type: "integer" },
          draws: { type: "integer" },
          losses: { type: "integer" },
          goals_for: { type: "integer" },
          goals_against: { type: "integer" },
          goal_difference: { type: "integer" },
          points: { type: "integer" },
          is_eschenbach: { type: "boolean" },
        },
        required: ["rank", "team", "played", "wins", "draws", "losses", "goals_for", "goals_against", "goal_difference", "points", "is_eschenbach"],
      },
    },
    upcoming_matches: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          date: { type: "string" },
          time: { type: "string" },
          home: { type: "string" },
          away: { type: "string" },
          is_eschenbach: { type: "boolean" },
          venue: { type: "string" },
          note: { type: "string" },
        },
        required: ["date", "time", "home", "away", "is_eschenbach", "venue", "note"],
      },
    },
    scorers: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          player: { type: "string" },
          goals: { type: "integer" },
        },
        required: ["player", "goals"],
      },
    },
    scorer_note: { type: "string" },
    players: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          name: { type: "string" },
          role: { type: "string" },
        },
        required: ["name", "role"],
      },
    },
    team_photo_url: { type: "string" },
    coach: { type: "string" },
    assistant_coach: { type: "string" },
  },
  required: [
    "report_date",
    "generated_at",
    "title",
    "lead",
    "review",
    "current_situation",
    "outlook",
    "eschenbach",
    "recent_results",
    "standings",
    "upcoming_matches",
    "scorers",
    "scorer_note",
    "players",
    "team_photo_url",
    "coach",
    "assistant_coach",
  ],
};

async function createReport() {
  const date = zurichDateISO();
  const generatedAt = generatedAtZurich();

  const systemPrompt = `
Du bist Sportredaktor für den Schweizer Amateurfussball.
Du erstellst täglich einen kompakten, faktentreuen Bericht zur IFV 5. Liga, Gruppe 4, mit starkem Fokus auf FC Eschenbach II.

Regeln:
- Schreibe auf Deutsch in Schweizer Standardsprache und verwende "ss" statt "ß".
- FC Eschenbach II erhält ca. 65–75 % der Aufmerksamkeit.
- Der offizielle IFV Matchcenter ist die primäre Quelle für Resultate, Tabelle, Spielplan, Torschützen, Karten und Aufstellungen.
- Suche zusätzlich nach Matchberichten auf Vereinswebseiten, regionalen Fussballseiten und weiteren öffentlich zugänglichen Quellen.
- Erfinde niemals Torschützen, Aufstellungen, Aussagen, Verletzungen oder Spielverläufe.
- Wenn zu einem Spiel kein ausführlicher Matchbericht auffindbar ist, sage das sinngemäss und stütze dich nur auf verifizierte Resultat-/Ereignisdaten.
- "Rückblick": relevante Spiele und Entwicklungen der letzten 7 Tage.
- "Aktuelle Situation": Tabelle, Form, Konkurrenzsituation und Einordnung.
- "Ausblick": nächste Spiele der kommenden 14 Tage und sportliche Bedeutung.
- Nenne bei Eschenbach-Partien verifizierte Torschützen/Schlüsselereignisse, wenn verfügbar.
- Führe in recent_results die wichtigsten jüngsten Gruppenresultate auf, mindestens aber alle Eschenbach-Meisterschaftsspiele der letzten 14 Tage, sofern vorhanden.
- Führe die vollständige aktuelle Gruppentabelle auf.
- Führe in upcoming_matches die kommenden Eschenbach-Spiele und besonders relevante Gruppenspiele auf.
- Erstelle scorers als nach Toren absteigende Liste der verifizierten Meisterschaftstorschützen von FC Eschenbach II. Zähle nur Tore, die sich aus offiziellen oder verlässlichen Detaildaten belegen lassen.
- Wenn die Torschützenangaben nicht für alle bisherigen Spiele vollständig verfügbar sind, erkläre das knapp und transparent in scorer_note.
- Recherchiere den aktuellen Kader der 2. Mannschaft auf der offiziellen Vereinsseite. Gib in players die Namen als role "Spieler" aus; Trainer und Assistent kommen separat in coach und assistant_coach.
- team_photo_url soll nach Möglichkeit exakt auf das aktuelle Mannschaftsfoto der Saison 2026/27 auf fceschenbach.ch zeigen; falls kein verlässlicher direkter Bildlink auffindbar ist, gib eine leere Zeichenkette aus.
- Resultate, Tabellenwerte und Termine müssen exakt sein.
`;

  const userPrompt = `
Stichtag: ${date}, Zeitzone Europe/Zurich.

Recherchiere jetzt die aktuelle Situation der IFV Meisterschaft 2026/2027, 5. Liga, Gruppe 4.
Fokus: FC Eschenbach II.

Bevorzugte offizielle Einstiegsseiten:
- https://matchcenter.ifv.ch/Default.aspx?ln=13040&lng=1&oid=7&s=2027
- https://matchcenter.ifv.ch/default.aspx?lng=1&oid=7&v=352
- https://fceschenbach.ch/aktive/2-mannschaft

Bekannter direkter Mannschaftsfoto-Link, nur verwenden wenn er weiterhin erreichbar und aktuell ist:
- https://fceschenbach.ch/images/mannschaftsbilder/Saison%2026-27/Zwoii-2026.jpg

Setze report_date exakt auf "${date}".
Setze generated_at exakt auf "${generatedAt}".
`;

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      reasoning: { effort: "medium" },
      tools: [{ type: "web_search", search_context_size: "high" }],
      include: ["web_search_call.action.sources"],
      input: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      text: {
        verbosity: "low",
        format: {
          type: "json_schema",
          name: "liga4_daily_report",
          strict: true,
          schema,
        },
      },
    }),
  });

  if (!response.ok) {
    throw new Error(`OpenAI ${response.status}: ${await response.text()}`);
  }

  const result = await response.json();
  if (!result.output_text) {
    throw new Error("OpenAI lieferte keinen output_text.");
  }

  const payload = JSON.parse(result.output_text);
  payload.sources = extractSources(result);

  const upsert = await fetch(`${SUPABASE_URL}/rest/v1/daily_reports?on_conflict=report_date`, {
    method: "POST",
    headers: {
      "apikey": SERVICE_ROLE_KEY,
      "Authorization": `Bearer ${SERVICE_ROLE_KEY}`,
      "Content-Type": "application/json",
      "Prefer": "resolution=merge-duplicates,return=representation",
    },
    body: JSON.stringify({
      report_date: date,
      generated_at: new Date().toISOString(),
      payload,
    }),
  });

  if (!upsert.ok) {
    throw new Error(`Supabase ${upsert.status}: ${await upsert.text()}`);
  }

  return { payload, sources: payload.sources };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    if (!OPENAI_API_KEY || !SUPABASE_URL || !SERVICE_ROLE_KEY) {
      throw new Error("Fehlende Server-Secrets: OPENAI_API_KEY / SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY.");
    }

    if (CRON_SECRET) {
      const provided = req.headers.get("x-cron-secret") ?? "";
      if (provided !== CRON_SECRET) {
        return new Response(JSON.stringify({ error: "unauthorized" }), {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    const result = await createReport();
    return new Response(JSON.stringify({ ok: true, report: result.payload, sources: result.sources }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ ok: false, error: String(error) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
