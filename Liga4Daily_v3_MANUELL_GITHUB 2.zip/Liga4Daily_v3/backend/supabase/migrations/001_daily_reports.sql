create table if not exists public.daily_reports (
  report_date date primary key,
  generated_at timestamptz not null default now(),
  payload jsonb not null
);

alter table public.daily_reports enable row level security;

drop policy if exists "daily_reports_public_read" on public.daily_reports;

create policy "daily_reports_public_read"
on public.daily_reports
for select
to anon, authenticated
using (true);

create index if not exists daily_reports_generated_at_idx
on public.daily_reports (generated_at desc);
