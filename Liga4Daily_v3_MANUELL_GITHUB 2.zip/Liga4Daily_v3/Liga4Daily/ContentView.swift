import SwiftUI
import Foundation

private enum ClubTheme {
    static let yellow = Color(red: 0.99, green: 0.82, blue: 0.04)
    static let black = Color.black
    static let photoURL = URL(string: "https://fceschenbach.ch/images/mannschaftsbilder/Saison%2026-27/Zwoii-2026.jpg")!
}

struct ContentView: View {
    @EnvironmentObject private var viewModel: ReportViewModel
    @State private var showSettings = false

    var body: some View {
        TabView {
            NavigationStack {
                HomeView(showSettings: $showSettings)
            }
            .tabItem {
                Label("Heute", systemImage: "newspaper.fill")
            }

            NavigationStack {
                StandingsView()
            }
            .tabItem {
                Label("Tabelle", systemImage: "list.number")
            }

            NavigationStack {
                TeamView()
            }
            .tabItem {
                Label("Team", systemImage: "person.3.fill")
            }
        }
        .tint(ClubTheme.black)
        .sheet(isPresented: $showSettings) {
            SettingsView()
                .environmentObject(viewModel)
        }
    }
}

private struct HomeView: View {
    @EnvironmentObject private var viewModel: ReportViewModel
    @Binding var showSettings: Bool

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 16) {
                featuredHeader
                quickStats
                matchOfTheWeek
                editorialSection(title: "Rückblick", eyebrow: "LETZTE 7 TAGE", icon: "clock.arrow.circlepath", text: viewModel.report.review)
                editorialSection(title: "Aktuelle Situation", eyebrow: "EINORDNUNG", icon: "chart.line.uptrend.xyaxis", text: viewModel.report.currentSituation)
                scorersPreview
                editorialSection(title: "Ausblick", eyebrow: "WAS KOMMT", icon: "binoculars.fill", text: viewModel.report.outlook)
                latestResults
                sources
                footer
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 28)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Liga 4 Daily")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button { showSettings = true } label: {
                    Image(systemName: "gearshape.fill")
                }
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    Task { await viewModel.load(force: true) }
                } label: {
                    if viewModel.isLoading {
                        ProgressView()
                    } else {
                        Image(systemName: "arrow.clockwise")
                    }
                }
                .disabled(viewModel.isLoading)
            }
        }
    }

    private var featuredHeader: some View {
        ZStack(alignment: .bottomLeading) {
            AsyncImage(url: URL(string: viewModel.report.teamPhotoURL ?? ClubTheme.photoURL.absoluteString)) { phase in
                switch phase {
                case .success(let image):
                    image.resizable().scaledToFill()
                default:
                    LinearGradient(colors: [.black, ClubTheme.yellow.opacity(0.7)], startPoint: .topLeading, endPoint: .bottomTrailing)
                }
            }
            .frame(height: 310)
            .clipped()

            LinearGradient(
                colors: [.clear, .black.opacity(0.18), .black.opacity(0.92)],
                startPoint: .top,
                endPoint: .bottom
            )

            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 8) {
                    BadgeView()
                    Text("5. LIGA · GRUPPE 4")
                        .font(.caption2.bold())
                        .tracking(1.5)
                        .foregroundStyle(.white.opacity(0.9))
                    Spacer()
                    if viewModel.isDemo {
                        Text("DEMO")
                            .font(.caption2.weight(.black))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 5)
                            .background(ClubTheme.yellow)
                            .foregroundStyle(.black)
                            .clipShape(Capsule())
                    }
                }

                Text(viewModel.report.title)
                    .font(.system(size: 30, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .fixedSize(horizontal: false, vertical: true)

                Text(viewModel.report.lead)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.white.opacity(0.9))
                    .lineSpacing(3)
            }
            .padding(18)
        }
        .frame(height: 310)
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay(alignment: .topTrailing) {
            Text("#\(viewModel.report.eschenbach.rank)")
                .font(.system(size: 42, weight: .black, design: .rounded))
                .foregroundStyle(.black)
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(ClubTheme.yellow)
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .padding(12)
        }
        .padding(.top, 8)
    }

    private var quickStats: some View {
        HStack(spacing: 10) {
            stat(value: "\(viewModel.report.eschenbach.points)", label: "PUNKTE")
            stat(value: "\(viewModel.report.eschenbach.goalsFor):\(viewModel.report.eschenbach.goalsAgainst)", label: "TORE")
            stat(value: viewModel.report.eschenbach.form, label: "FORM")
        }
    }

    private func stat(value: String, label: String) -> some View {
        VStack(spacing: 6) {
            Text(value)
                .font(.headline.weight(.black))
                .minimumScaleFactor(0.6)
                .lineLimit(1)
            Text(label)
                .font(.caption2.bold())
                .tracking(0.8)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(Color(.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    @ViewBuilder
    private var matchOfTheWeek: some View {
        if let match = viewModel.report.upcomingMatches.first(where: { $0.isEschenbach }) {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text("NÄCHSTES SPIEL")
                        .font(.caption2.weight(.black))
                        .tracking(1.4)
                    Spacer()
                    Text("\(match.date) · \(match.time)")
                        .font(.caption.bold())
                }

                HStack(spacing: 12) {
                    TeamNameBox(name: match.home, alignRight: false)
                    Text("VS")
                        .font(.caption.weight(.black))
                        .foregroundStyle(.secondary)
                    TeamNameBox(name: match.away, alignRight: true)
                }

                if !match.note.isEmpty {
                    Text(match.note)
                        .font(.subheadline.weight(.semibold))
                }
                if !match.venue.isEmpty {
                    Label(match.venue, systemImage: "mappin.and.ellipse")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(16)
            .background(ClubTheme.yellow)
            .foregroundStyle(.black)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
    }

    private func editorialSection(title: String, eyebrow: String, icon: String, text: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(eyebrow)
                        .font(.caption2.weight(.black))
                        .tracking(1.5)
                        .foregroundStyle(.secondary)
                    Text(title)
                        .font(.title3.weight(.black))
                }
                Spacer()
                Image(systemName: icon)
                    .font(.title3.bold())
                    .foregroundStyle(ClubTheme.yellow)
                    .padding(10)
                    .background(Color.black)
                    .clipShape(Circle())
            }

            Text(text)
                .font(.body)
                .lineSpacing(5)
                .textSelection(.enabled)
        }
        .sportsCard()
    }

    @ViewBuilder
    private var scorersPreview: some View {
        let scorers = viewModel.report.scorers ?? []
        if !scorers.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("ESCHENBACH II")
                            .font(.caption2.weight(.black))
                            .tracking(1.3)
                            .foregroundStyle(.secondary)
                        Text("Torschützen")
                            .font(.title3.weight(.black))
                    }
                    Spacer()
                    Image(systemName: "soccerball")
                        .font(.title2)
                }

                ForEach(Array(scorers.prefix(5).enumerated()), id: \.element.id) { index, scorer in
                    HStack {
                        Text("\(index + 1)")
                            .font(.caption.weight(.black))
                            .frame(width: 26, height: 26)
                            .background(index == 0 ? ClubTheme.yellow : Color(.tertiarySystemGroupedBackground))
                            .clipShape(Circle())
                        Text(scorer.player)
                            .font(.subheadline.weight(.semibold))
                        Spacer()
                        Text("\(scorer.goals)")
                            .font(.headline.weight(.black).monospacedDigit())
                        Text(scorer.goals == 1 ? "Tor" : "Tore")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }

                if let note = viewModel.report.scorerNote, !note.isEmpty {
                    Text(note)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .sportsCard()
        }
    }

    private var latestResults: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("LETZTE RESULTATE")
                .font(.caption2.weight(.black))
                .tracking(1.5)
                .foregroundStyle(.secondary)

            ForEach(viewModel.report.recentResults) { match in
                VStack(alignment: .leading, spacing: 7) {
                    HStack {
                        Text(match.date)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Spacer()
                        Text("\(match.homeGoals):\(match.awayGoals)")
                            .font(.title2.weight(.black).monospacedDigit())
                    }
                    HStack(alignment: .top) {
                        Text(match.home)
                        Spacer()
                        Text(match.away)
                            .multilineTextAlignment(.trailing)
                    }
                    .font(.subheadline.weight(.semibold))

                    if !match.note.isEmpty {
                        Text(match.note)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(12)
                .background(match.isEschenbach ? ClubTheme.yellow.opacity(0.22) : Color(.tertiarySystemGroupedBackground))
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
        .sportsCard()
    }

    private var sources: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("QUELLEN")
                .font(.caption2.weight(.black))
                .tracking(1.5)
                .foregroundStyle(.secondary)

            ForEach(viewModel.report.sources) { source in
                if let url = URL(string: source.url) {
                    Link(destination: url) {
                        HStack {
                            Text(source.title.isEmpty ? (url.host() ?? source.url) : source.title)
                                .font(.subheadline.weight(.semibold))
                                .multilineTextAlignment(.leading)
                            Spacer()
                            Image(systemName: "arrow.up.right.square")
                        }
                        .foregroundStyle(.primary)
                    }
                    .padding(.vertical, 3)
                }
            }
        }
        .sportsCard()
    }

    private var footer: some View {
        VStack(spacing: 4) {
            Text("Bericht: \(viewModel.report.reportDate)")
            Text("Generiert: \(viewModel.report.generatedAt)")
            if let error = viewModel.errorMessage, viewModel.isDemo {
                Text(error)
            }
        }
        .font(.caption2)
        .foregroundStyle(.secondary)
        .multilineTextAlignment(.center)
        .padding(.top, 4)
    }
}

private struct StandingsView: View {
    @EnvironmentObject private var viewModel: ReportViewModel

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                tableHero
                standings
                upcoming
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Gruppe 4")
    }

    private var tableHero: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("FC ESCHENBACH II")
                    .font(.caption.weight(.black))
                    .tracking(1.2)
                Text("Tabellenführer")
                    .font(.title2.weight(.black))
                Text("\(viewModel.report.eschenbach.points) Punkte · \(viewModel.report.eschenbach.goalDifference >= 0 ? "+" : "")\(viewModel.report.eschenbach.goalDifference) Tordifferenz")
                    .font(.subheadline.weight(.medium))
            }
            Spacer()
            Text("1")
                .font(.system(size: 52, weight: .black, design: .rounded))
        }
        .padding(18)
        .background(ClubTheme.yellow)
        .foregroundStyle(.black)
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private var standings: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("RANG / TEAM")
                Spacer()
                Text("SP").frame(width: 28)
                Text("TD").frame(width: 34)
                Text("PKT").frame(width: 34)
            }
            .font(.caption2.weight(.black))
            .tracking(0.8)
            .foregroundStyle(.secondary)

            ForEach(viewModel.report.standings) { row in
                HStack(spacing: 8) {
                    Text("\(row.rank).")
                        .font(.subheadline.monospacedDigit().weight(.semibold))
                        .frame(width: 25, alignment: .leading)
                    Text(row.team)
                        .font(.subheadline.weight(row.isEschenbach ? .black : .medium))
                        .lineLimit(1)
                    Spacer()
                    Text("\(row.played)").frame(width: 28)
                    Text(row.goalDifference >= 0 ? "+\(row.goalDifference)" : "\(row.goalDifference)").frame(width: 34)
                    Text("\(row.points)")
                        .fontWeight(row.isEschenbach ? .black : .semibold)
                        .frame(width: 34)
                }
                .font(.subheadline.monospacedDigit())
                .padding(.vertical, 10)
                .padding(.horizontal, 8)
                .background(row.isEschenbach ? ClubTheme.yellow : Color.clear)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            }
        }
        .sportsCard()
    }

    private var upcoming: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("NÄCHSTE SPIELE")
                .font(.caption2.weight(.black))
                .tracking(1.4)
                .foregroundStyle(.secondary)

            ForEach(viewModel.report.upcomingMatches) { match in
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("\(match.date) · \(match.time)")
                            .font(.caption.bold())
                        Spacer()
                        if match.isEschenbach { Image(systemName: "star.fill") }
                    }
                    Text("\(match.home) – \(match.away)")
                        .font(.subheadline.bold())
                    if !match.venue.isEmpty {
                        Label(match.venue, systemImage: "mappin.and.ellipse")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    if !match.note.isEmpty {
                        Text(match.note)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(12)
                .background(match.isEschenbach ? ClubTheme.yellow.opacity(0.2) : Color(.tertiarySystemGroupedBackground))
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
        .sportsCard()
    }
}

private struct TeamView: View {
    @EnvironmentObject private var viewModel: ReportViewModel

    private var players: [PlayerProfile] {
        viewModel.report.players ?? []
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                teamPhoto
                coaches
                scorers
                roster
                officialLink
            }
            .padding(16)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Eschenbach II")
    }

    private var teamPhoto: some View {
        VStack(alignment: .leading, spacing: 0) {
            AsyncImage(url: URL(string: viewModel.report.teamPhotoURL ?? ClubTheme.photoURL.absoluteString)) { phase in
                switch phase {
                case .success(let image):
                    image.resizable().scaledToFill()
                default:
                    ZStack {
                        ClubTheme.yellow
                        Image(systemName: "person.3.fill")
                            .font(.system(size: 48))
                    }
                }
            }
            .frame(height: 230)
            .clipped()

            HStack {
                BadgeView()
                VStack(alignment: .leading, spacing: 2) {
                    Text("2. MANNSCHAFT")
                        .font(.caption2.weight(.black))
                        .tracking(1.4)
                    Text("Saison 2026/27")
                        .font(.headline.weight(.black))
                }
                Spacer()
                Text("5. Liga")
                    .font(.caption.bold())
            }
            .padding(14)
            .background(.black)
            .foregroundStyle(.white)
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private var coaches: some View {
        HStack(spacing: 10) {
            personCard(title: "TRAINER", name: viewModel.report.coach ?? "Daniel Muff", icon: "figure.soccer")
            personCard(title: "ASSISTENT", name: viewModel.report.assistantCoach ?? "Elia Fischer-Amstutz", icon: "person.fill.checkmark")
        }
    }

    private func personCard(title: String, name: String, icon: String) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            Image(systemName: icon)
                .font(.title3.bold())
            Text(title)
                .font(.caption2.weight(.black))
                .tracking(1.1)
                .foregroundStyle(.secondary)
            Text(name)
                .font(.subheadline.weight(.black))
                .lineLimit(2)
        }
        .frame(maxWidth: .infinity, minHeight: 108, alignment: .topLeading)
        .padding(14)
        .background(Color(.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    @ViewBuilder
    private var scorers: some View {
        let data = viewModel.report.scorers ?? []
        if !data.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text("TORSCHÜTZEN")
                        .font(.caption2.weight(.black))
                        .tracking(1.4)
                    Spacer()
                    Image(systemName: "soccerball")
                }

                ForEach(data) { scorer in
                    HStack {
                        Text(scorer.player)
                            .font(.subheadline.weight(.semibold))
                        Spacer()
                        Text("\(scorer.goals)")
                            .font(.headline.weight(.black).monospacedDigit())
                    }
                    .padding(.vertical, 3)
                }

                if let note = viewModel.report.scorerNote, !note.isEmpty {
                    Divider()
                    Text(note)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .sportsCard()
        }
    }

    private var roster: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("KADER 2026/27")
                    .font(.caption2.weight(.black))
                    .tracking(1.4)
                Spacer()
                Text("\(players.count) Spieler")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            ForEach(Array(players.enumerated()), id: \.element.id) { index, player in
                HStack {
                    Text(String(format: "%02d", index + 1))
                        .font(.caption.monospacedDigit().bold())
                        .foregroundStyle(.secondary)
                        .frame(width: 28, alignment: .leading)
                    Text(player.name)
                        .font(.subheadline.weight(.semibold))
                    Spacer()
                    Text(player.role)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 5)
            }
        }
        .sportsCard()
    }

    private var officialLink: some View {
        Link(destination: URL(string: "https://fceschenbach.ch/aktive/2-mannschaft")!) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("OFFIZIELLE TEAMSEITE")
                        .font(.caption2.weight(.black))
                        .tracking(1.2)
                    Text("FC Eschenbach")
                        .font(.headline.weight(.black))
                }
                Spacer()
                Image(systemName: "arrow.up.right")
                    .font(.title3.bold())
            }
            .padding(16)
            .background(ClubTheme.yellow)
            .foregroundStyle(.black)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
    }
}

private struct BadgeView: View {
    var body: some View {
        ZStack {
            Circle()
                .fill(ClubTheme.yellow)
                .frame(width: 42, height: 42)
            Circle()
                .stroke(.black, lineWidth: 3)
                .frame(width: 34, height: 34)
            Text("FCE")
                .font(.caption2.weight(.black))
                .foregroundStyle(.black)
        }
    }
}

private struct TeamNameBox: View {
    let name: String
    let alignRight: Bool

    var body: some View {
        Text(name.replacingOccurrences(of: "FC ", with: ""))
            .font(.subheadline.weight(.black))
            .multilineTextAlignment(alignRight ? .trailing : .leading)
            .frame(maxWidth: .infinity, alignment: alignRight ? .trailing : .leading)
    }
}

private extension View {
    func sportsCard() -> some View {
        self
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(.secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}
