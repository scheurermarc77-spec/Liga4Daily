import Foundation
import UserNotifications

enum NotificationManager {
    static let identifier = "liga4.daily.reminder"

    static func applyCurrentSettings() async {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [identifier])

        guard AppSettings.notificationsEnabled else { return }

        do {
            let granted = try await center.requestAuthorization(options: [.alert, .sound, .badge])
            guard granted else { return }

            var components = DateComponents()
            components.hour = AppSettings.notificationHour
            components.minute = AppSettings.notificationMinute

            let content = UNMutableNotificationContent()
            content.title = "Liga 4 Daily"
            content.body = "Der neue Tagesbericht zu Eschenbach II ist bereit."
            content.sound = .default

            let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: true)
            let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
            try await center.add(request)
        } catch {
            // Die App funktioniert auch ohne Benachrichtigungen.
        }
    }
}
