import Foundation

enum ReportCache {
    private static let key = "cachedDailyReport"

    static func save(_ report: DailyReport) {
        guard let data = try? JSONEncoder().encode(report) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }

    static func load() -> DailyReport? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(DailyReport.self, from: data)
    }
}
