import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var viewModel: ReportViewModel

    @State private var supabaseURL = AppSettings.supabaseURL
    @State private var supabaseKey = AppSettings.supabaseKey
    @State private var notificationsEnabled = AppSettings.notificationsEnabled
    @State private var notificationDate: Date = {
        var components = DateComponents()
        components.hour = AppSettings.notificationHour
        components.minute = AppSettings.notificationMinute
        return Calendar.current.date(from: components) ?? Date()
    }()

    var body: some View {
        NavigationStack {
            Form {
                Section("Datenquelle") {
                    TextField("https://…supabase.co", text: $supabaseURL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    SecureField("Publishable / anon key", text: $supabaseKey)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    Text("Der Publishable/anon Key darf in einer App verwendet werden. Der OpenAI-Key bleibt ausschliesslich im Backend.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("Tägliche Erinnerung") {
                    Toggle("Benachrichtigung", isOn: $notificationsEnabled)
                    DatePicker(
                        "Zeit",
                        selection: $notificationDate,
                        displayedComponents: .hourAndMinute
                    )
                    .disabled(!notificationsEnabled)
                }

                Section {
                    Text("Ohne Supabase-Konfiguration zeigt die App die integrierte Demo mit dem Stand vom 5. September 2026.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Einstellungen")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Abbrechen") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Sichern") {
                        AppSettings.supabaseURL = supabaseURL
                        AppSettings.supabaseKey = supabaseKey
                        AppSettings.notificationsEnabled = notificationsEnabled

                        let parts = Calendar.current.dateComponents([.hour, .minute], from: notificationDate)
                        AppSettings.notificationHour = parts.hour ?? 8
                        AppSettings.notificationMinute = parts.minute ?? 0

                        Task {
                            await NotificationManager.applyCurrentSettings()
                            await viewModel.load(force: true)
                            dismiss()
                        }
                    }
                    .fontWeight(.semibold)
                }
            }
        }
    }
}
