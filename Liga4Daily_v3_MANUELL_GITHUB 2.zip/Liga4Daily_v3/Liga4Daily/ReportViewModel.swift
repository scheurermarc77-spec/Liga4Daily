import Foundation
import SwiftUI

@MainActor
final class ReportViewModel: ObservableObject {
    @Published var report: DailyReport = DemoData.report
    @Published var isLoading = false
    @Published var isDemo = true
    @Published var errorMessage: String?

    private let api = ReportAPI()

    func load(force: Bool = false) async {
        if isLoading { return }
        isLoading = true
        errorMessage = nil

        if !force, let cached = ReportCache.load() {
            report = cached
            isDemo = false
        }

        do {
            let fresh = try await api.latest()
            report = fresh
            isDemo = false
            ReportCache.save(fresh)
        } catch {
            if ReportCache.load() == nil {
                report = DemoData.report
                isDemo = true
            }
            errorMessage = error.localizedDescription
        }

        await NotificationManager.applyCurrentSettings()
        isLoading = false
    }
}
