import Foundation

enum ReportAPIError: LocalizedError {
    case invalidConfiguration
    case badResponse(Int)
    case noReport

    var errorDescription: String? {
        switch self {
        case .invalidConfiguration:
            return "Supabase ist noch nicht konfiguriert."
        case .badResponse(let status):
            return "Der Server antwortete mit Status \(status)."
        case .noReport:
            return "Noch kein Tagesbericht vorhanden."
        }
    }
}

struct ReportAPI {
    private let decoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return decoder
    }()

    func latest() async throws -> DailyReport {
        guard AppSettings.isConfigured else {
            throw ReportAPIError.invalidConfiguration
        }

        let base = AppSettings.supabaseURL.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard let url = URL(string: "\(base)/rest/v1/daily_reports?select=payload&order=report_date.desc&limit=1") else {
            throw ReportAPIError.invalidConfiguration
        }

        var request = URLRequest(url: url)
        request.timeoutInterval = 20
        request.setValue(AppSettings.supabaseKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(AppSettings.supabaseKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw ReportAPIError.badResponse(-1)
        }
        guard (200..<300).contains(http.statusCode) else {
            throw ReportAPIError.badResponse(http.statusCode)
        }

        let rows = try decoder.decode([ReportRow].self, from: data)
        guard let report = rows.first?.payload else {
            throw ReportAPIError.noReport
        }
        return report
    }
}
