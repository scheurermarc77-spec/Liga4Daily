import Foundation

struct DailyReport: Codable, Hashable {
    let reportDate: String
    let generatedAt: String
    let title: String
    let lead: String
    let review: String
    let currentSituation: String
    let outlook: String
    let eschenbach: EschenbachSnapshot
    let recentResults: [MatchResult]
    let standings: [StandingRow]
    let upcomingMatches: [UpcomingMatch]
    let sources: [SourceLink]

    // V2: Zusatzbereiche. Optional, damit auch ältere gespeicherte Berichte weiterhin lesbar bleiben.
    let scorers: [ScorerRow]?
    let scorerNote: String?
    let players: [PlayerProfile]?
    let teamPhotoURL: String?
    let coach: String?
    let assistantCoach: String?
}

struct EschenbachSnapshot: Codable, Hashable {
    let rank: Int
    let played: Int
    let wins: Int
    let draws: Int
    let losses: Int
    let goalsFor: Int
    let goalsAgainst: Int
    let goalDifference: Int
    let points: Int
    let form: String
}

struct MatchResult: Codable, Hashable, Identifiable {
    var id: String { "\(date)-\(home)-\(away)" }
    let date: String
    let home: String
    let away: String
    let homeGoals: Int
    let awayGoals: Int
    let isEschenbach: Bool
    let note: String
}

struct StandingRow: Codable, Hashable, Identifiable {
    var id: String { team }
    let rank: Int
    let team: String
    let played: Int
    let wins: Int
    let draws: Int
    let losses: Int
    let goalsFor: Int
    let goalsAgainst: Int
    let goalDifference: Int
    let points: Int
    let isEschenbach: Bool
}

struct UpcomingMatch: Codable, Hashable, Identifiable {
    var id: String { "\(date)-\(time)-\(home)-\(away)" }
    let date: String
    let time: String
    let home: String
    let away: String
    let isEschenbach: Bool
    let venue: String
    let note: String
}

struct SourceLink: Codable, Hashable, Identifiable {
    var id: String { url }
    let title: String
    let url: String
}

struct ScorerRow: Codable, Hashable, Identifiable {
    var id: String { player }
    let player: String
    let goals: Int
}

struct PlayerProfile: Codable, Hashable, Identifiable {
    var id: String { name }
    let name: String
    let role: String
}

struct ReportRow: Decodable {
    let payload: DailyReport
}
