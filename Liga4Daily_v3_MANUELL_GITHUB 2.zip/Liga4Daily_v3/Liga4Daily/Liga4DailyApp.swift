import SwiftUI

@main
struct Liga4DailyApp: App {
    @StateObject private var viewModel = ReportViewModel()
    @State private var showSplash = true

    var body: some Scene {
        WindowGroup {
            ZStack {
                ContentView()
                    .environmentObject(viewModel)
                    .task {
                        await viewModel.load()
                    }

                if showSplash {
                    SplashView()
                        .transition(.opacity)
                        .zIndex(10)
                        .task {
                            try? await Task.sleep(for: .seconds(1.25))
                            withAnimation(.easeOut(duration: 0.35)) {
                                showSplash = false
                            }
                        }
                }
            }
        }
    }
}

private struct SplashView: View {
    private let yellow = Color(red: 0.99, green: 0.82, blue: 0.04)

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 20) {
                ZStack {
                    Circle()
                        .fill(yellow)
                        .frame(width: 132, height: 132)
                    Circle()
                        .stroke(.black, lineWidth: 7)
                        .frame(width: 108, height: 108)
                    Text("FCE")
                        .font(.system(size: 42, weight: .black, design: .rounded))
                        .foregroundStyle(.black)
                }

                VStack(spacing: 6) {
                    Text("FC ESCHENBACH II")
                        .font(.title2.weight(.black))
                        .tracking(1.2)
                    Text("LIGA 4 DAILY")
                        .font(.caption.bold())
                        .tracking(3)
                        .foregroundStyle(yellow)
                }
                .foregroundStyle(.white)
            }
        }
    }
}
