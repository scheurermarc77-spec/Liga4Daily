import Foundation

enum AppSettings {
    private enum Keys {
        static let supabaseURL = "supabaseURL"
        static let supabaseKey = "supabaseKey"
        static let notificationsEnabled = "notificationsEnabled"
        static let notificationHour = "notificationHour"
        static let notificationMinute = "notificationMinute"
    }

    static var supabaseURL: String {
        get { UserDefaults.standard.string(forKey: Keys.supabaseURL) ?? "" }
        set { UserDefaults.standard.set(newValue.trimmingCharacters(in: .whitespacesAndNewlines), forKey: Keys.supabaseURL) }
    }

    static var supabaseKey: String {
        get { UserDefaults.standard.string(forKey: Keys.supabaseKey) ?? "" }
        set { UserDefaults.standard.set(newValue.trimmingCharacters(in: .whitespacesAndNewlines), forKey: Keys.supabaseKey) }
    }

    static var notificationsEnabled: Bool {
        get {
            if UserDefaults.standard.object(forKey: Keys.notificationsEnabled) == nil { return true }
            return UserDefaults.standard.bool(forKey: Keys.notificationsEnabled)
        }
        set { UserDefaults.standard.set(newValue, forKey: Keys.notificationsEnabled) }
    }

    static var notificationHour: Int {
        get {
            let value = UserDefaults.standard.integer(forKey: Keys.notificationHour)
            return UserDefaults.standard.object(forKey: Keys.notificationHour) == nil ? 8 : value
        }
        set { UserDefaults.standard.set(newValue, forKey: Keys.notificationHour) }
    }

    static var notificationMinute: Int {
        get { UserDefaults.standard.integer(forKey: Keys.notificationMinute) }
        set { UserDefaults.standard.set(newValue, forKey: Keys.notificationMinute) }
    }

    static var isConfigured: Bool {
        !supabaseURL.isEmpty && !supabaseKey.isEmpty
    }
}
