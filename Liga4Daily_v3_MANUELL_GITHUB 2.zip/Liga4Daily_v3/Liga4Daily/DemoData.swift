import Foundation

enum DemoData {
    static let report = DailyReport(
        reportDate: "2026-09-05",
        generatedAt: "2026-09-05T13:30:00+02:00",
        title: "Eschenbach II startet makellos",
        lead: "Drei Meisterschaftsspiele, drei Siege: Eschenbach II führt die 5. Liga Gruppe 4 mit 9 Punkten und 14:4 Toren an.",
        review: "Der jüngste Auftritt endete am 4. September auswärts beim FC Grosswangen-Ettiswil mit einem 3:0-Sieg. Zuvor gewann Eschenbach II zuhause gegen Wauwil-Egolzwil 5:2. In dieser Partie trafen Tilman Bucher, Nando Hächler, Ramon Brugger, Luca Ulrich und Sandro Rosenberg. Zum Saisonauftakt gab es bereits ein 6:2 bei Altbüron-Grossdietwil. Die Mannschaft hat damit in allen drei Meisterschaftsspielen mindestens drei Tore erzielt.",
        currentSituation: "Eschenbach II steht an der Tabellenspitze. Knutwil II und Hochdorf III liegen mit je 6 Punkten dahinter, wobei Knutwil erst zwei Partien absolviert hat. Hochdorf weist dank des 16:0 gegen Schötz eine aussergewöhnlich hohe Tordifferenz auf. Für Eschenbach ist besonders positiv, dass die Offensive konstant produziert und die Gegentorzahl nach drei Spielen bei nur vier liegt.",
        outlook: "Am Samstag, 12. September, kommt es in Eschenbach zum direkten Duell mit Knutwil II. Der Gegner ist ebenfalls verlustpunktfrei und dürfte der erste echte Gradmesser im Kampf um die Spitze sein. Danach folgt am 26. September das Auswärtsspiel beim SC Nebikon.",
        eschenbach: EschenbachSnapshot(
            rank: 1, played: 3, wins: 3, draws: 0, losses: 0,
            goalsFor: 14, goalsAgainst: 4, goalDifference: 10, points: 9,
            form: "S – S – S"
        ),
        recentResults: [
            MatchResult(date: "04.09.2026", home: "FC Grosswangen-Ettiswil", away: "FC Eschenbach II", homeGoals: 0, awayGoals: 3, isEschenbach: true, note: "3. Meisterschaftssieg in Serie"),
            MatchResult(date: "30.08.2026", home: "FC Eschenbach II", away: "FC Wauwil-Egolzwil", homeGoals: 5, awayGoals: 2, isEschenbach: true, note: "Tore: Bucher, Hächler, Brugger, Ulrich, Rosenberg"),
            MatchResult(date: "22.08.2026", home: "FC Altbüron-Grossdietwil", away: "FC Eschenbach II", homeGoals: 2, awayGoals: 6, isEschenbach: true, note: "Tore: Eigentor, Nabulon (2), Häusler, Brugger, Brandenberger")
        ],
        standings: [
            StandingRow(rank: 1, team: "FC Eschenbach II", played: 3, wins: 3, draws: 0, losses: 0, goalsFor: 14, goalsAgainst: 4, goalDifference: 10, points: 9, isEschenbach: true),
            StandingRow(rank: 2, team: "FC Knutwil II", played: 2, wins: 2, draws: 0, losses: 0, goalsFor: 8, goalsAgainst: 2, goalDifference: 6, points: 6, isEschenbach: false),
            StandingRow(rank: 3, team: "FC Hochdorf III", played: 3, wins: 2, draws: 0, losses: 1, goalsFor: 24, goalsAgainst: 4, goalDifference: 20, points: 6, isEschenbach: false),
            StandingRow(rank: 4, team: "FC Dagmersellen", played: 1, wins: 1, draws: 0, losses: 0, goalsFor: 2, goalsAgainst: 1, goalDifference: 1, points: 3, isEschenbach: false),
            StandingRow(rank: 5, team: "FC Wauwil-Egolzwil", played: 2, wins: 1, draws: 0, losses: 1, goalsFor: 7, goalsAgainst: 7, goalDifference: 0, points: 3, isEschenbach: false),
            StandingRow(rank: 6, team: "FC Altbüron-Grossdietwil", played: 2, wins: 1, draws: 0, losses: 1, goalsFor: 5, goalsAgainst: 8, goalDifference: -3, points: 3, isEschenbach: false),
            StandingRow(rank: 7, team: "SC Nebikon", played: 1, wins: 0, draws: 0, losses: 1, goalsFor: 2, goalsAgainst: 5, goalDifference: -3, points: 0, isEschenbach: false),
            StandingRow(rank: 8, team: "FC Grosswangen-Ettiswil", played: 2, wins: 0, draws: 0, losses: 2, goalsFor: 2, goalsAgainst: 8, goalDifference: -6, points: 0, isEschenbach: false),
            StandingRow(rank: 9, team: "FC Ruswil III", played: 2, wins: 0, draws: 0, losses: 2, goalsFor: 2, goalsAgainst: 8, goalDifference: -6, points: 0, isEschenbach: false),
            StandingRow(rank: 10, team: "FC Schötz III", played: 2, wins: 0, draws: 0, losses: 2, goalsFor: 0, goalsAgainst: 19, goalDifference: -19, points: 0, isEschenbach: false)
        ],
        upcomingMatches: [
            UpcomingMatch(date: "12.09.2026", time: "19:00", home: "FC Eschenbach II", away: "FC Knutwil II", isEschenbach: true, venue: "Weiherhus – Nebenplatz (2), Eschenbach", note: "Direktes Duell zweier verlustpunktfreier Teams"),
            UpcomingMatch(date: "26.09.2026", time: "17:00", home: "SC Nebikon", away: "FC Eschenbach II", isEschenbach: true, venue: "Nebikon", note: "")
        ],
        sources: [
            SourceLink(title: "IFV Matchcenter – 5. Liga Gruppe 4", url: "https://matchcenter.ifv.ch/Default.aspx?ln=13040&lng=1&oid=7&s=2027"),
            SourceLink(title: "IFV – FC Eschenbach", url: "https://matchcenter.ifv.ch/default.aspx?lng=1&oid=7&v=352"),
            SourceLink(title: "FC Eschenbach – 2. Mannschaft", url: "https://fceschenbach.ch/aktive/2-mannschaft")
        ],
        scorers: [
            ScorerRow(player: "Luis Nabulon", goals: 2),
            ScorerRow(player: "Ramon Brugger", goals: 2),
            ScorerRow(player: "Tilman Bucher", goals: 1),
            ScorerRow(player: "Nando Hächler", goals: 1),
            ScorerRow(player: "Joel Häusler", goals: 1),
            ScorerRow(player: "Ilay Brandenberger", goals: 1),
            ScorerRow(player: "Luca Ulrich", goals: 1),
            ScorerRow(player: "Sandro Rosenberg", goals: 1)
        ],
        scorerNote: "Verifizierte Torschützen aus den öffentlich zugänglichen Detaildaten der ersten beiden Meisterschaftsspiele. Für das 3:0 in Grosswangen waren bei Erstellung der Demo noch keine Torschützen publiziert.",
        players: [
            PlayerProfile(name: "Stefano Scarcia", role: "Spieler"),
            PlayerProfile(name: "Ilay Brandenberger", role: "Spieler"),
            PlayerProfile(name: "Joel Häusler", role: "Spieler"),
            PlayerProfile(name: "Nando Hächler", role: "Spieler"),
            PlayerProfile(name: "Lenn Merz", role: "Spieler"),
            PlayerProfile(name: "Timo Bossert", role: "Spieler"),
            PlayerProfile(name: "Leon Scheurer", role: "Spieler"),
            PlayerProfile(name: "Mino Vidi", role: "Spieler"),
            PlayerProfile(name: "Jannis Brandmaier", role: "Spieler"),
            PlayerProfile(name: "Ramon Brugger", role: "Spieler"),
            PlayerProfile(name: "Luca Ulrich", role: "Spieler"),
            PlayerProfile(name: "Riccardo Caruso", role: "Spieler"),
            PlayerProfile(name: "Tilman Bucher", role: "Spieler"),
            PlayerProfile(name: "Noe Fischer", role: "Spieler"),
            PlayerProfile(name: "Samuel Muff", role: "Spieler"),
            PlayerProfile(name: "Jan Bienz", role: "Spieler"),
            PlayerProfile(name: "Tim Gürber", role: "Spieler"),
            PlayerProfile(name: "Nico Röösli", role: "Spieler"),
            PlayerProfile(name: "Lian Burkart", role: "Spieler"),
            PlayerProfile(name: "Luis Nabulon", role: "Spieler"),
            PlayerProfile(name: "Tobias Heini", role: "Spieler")
        ],
        teamPhotoURL: "https://fceschenbach.ch/images/mannschaftsbilder/Saison%2026-27/Zwoii-2026.jpg",
        coach: "Daniel Muff",
        assistantCoach: "Elia Fischer-Amstutz"
    )
}
